import sqlite3, os, tkinter as tk
from tkinter import ttk, messagebox

BASE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(BASE, "shop.db")
ICO = os.path.join(BASE, "Icon.ico")
BG, BG2, AC, HI = "#FFFFFF", "#7FFF00", "#00FA9A", "#2E8B57"
F = ("Times New Roman", 11); FB = ("Times New Roman", 11, "bold")

def db():
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row; c.execute("PRAGMA foreign_keys=ON"); return c

def init():
    c = db(); x = c.cursor()
    x.execute("PRAGMA foreign_keys = ON")
    x.executescript("""
    CREATE TABLE users(id INTEGER PRIMARY KEY, login TEXT UNIQUE, pwd TEXT, role TEXT);
    CREATE TABLE suppliers(id INTEGER PRIMARY KEY, name TEXT UNIQUE);
    CREATE TABLE makers(id INTEGER PRIMARY KEY, name TEXT UNIQUE);
    CREATE TABLE categories(id INTEGER PRIMARY KEY, name TEXT UNIQUE);
    CREATE TABLE products(article TEXT PRIMARY KEY, name TEXT, price REAL,
        supplier_id INT REFERENCES suppliers(id), maker_id INT REFERENCES makers(id),
        category_id INT REFERENCES categories(id), discount INT, stock INT, photo TEXT);
    CREATE TABLE orders(id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INT REFERENCES users(id), article TEXT REFERENCES products(article), status TEXT);
    """)
    x.executemany("INSERT INTO users(login,pwd,role) VALUES(?,?,?)",
        [("admin","1","admin"),("manager","1","manager"),("client","1","client")])
    x.executemany("INSERT INTO suppliers(id,name) VALUES(?,?)", [(1,"Kari"),(2,"Обувь для вас")])
    x.executemany("INSERT INTO makers(id,name) VALUES(?,?)",
        [(1,"Kari"),(2,"Marco Tozzi"),(3,"Рос"),(4,"Rieker"),(5,"Alessio Nesca"),(6,"CROSBY")])
    x.executemany("INSERT INTO categories(id,name) VALUES(?,?)", [(1,"Женская обувь"),(2,"Мужская обувь")])
    
    
    prods = [
        ('А112Т4','Ботинки',4990,1,1,1,3,6,'1.jpg'),('F635R4','Ботинки',3244,2,2,1,2,13,'2.jpg'),
        ('H782T5','Туфли',4499,1,1,2,4,5,'3.jpg'),('G783F5','Ботинки',5900,1,3,2,2,8,'4.jpg'),
        ('J384T6','Ботинки',3800,2,4,2,2,16,'5.jpg'),('D572U8','Кроссовки',4100,2,3,2,3,6,'6.jpg'),
        ('F572H7','Туфли',2700,1,2,1,2,14,'7.jpg'),('D329H3','Полуботинки',1890,2,5,1,4,4,'8.jpg'),
        ('B320R5','Туфли',4300,1,4,1,2,6,'9.jpg'),('G432E4','Туфли',2800,1,1,1,3,15,'10.jpg'),
        ('S213E3','Полуботинки',2156,2,6,2,3,6,None),('E482R4','Полуботинки',1800,1,1,1,2,14,None),
        ('S634B5','Кеды',5500,2,6,2,3,0,None),('K345R4','Полуботинки',2100,2,6,2,2,3,None),
        ('O754F4','Туфли',5400,2,4,1,4,18,None),('G531F4','Ботинки',6600,1,1,1,12,9,None),
        ('J542F5','Тапочки',500,1,1,2,13,0,None),('B431R5','Ботинки',2700,2,4,2,2,5,None),
        ('P764G4','Туфли',6800,1,6,1,15,15,None),('C436G5','Ботинки',10200,1,5,1,15,9,None),
        ('F427R5','Ботинки',11800,2,4,1,15,11,None),('N457T5','Полуботинки',4600,1,6,1,3,13,None),
        ('D364R4','Туфли',12400,1,1,1,16,5,None),('S326R5','Тапочки',9900,2,6,2,17,15,None),
        ('L754R4','Полуботинки',1700,1,1,1,2,7,None),('M542T5','Кроссовки',2800,2,4,2,18,3,None),
        ('D268G5','Туфли',4399,2,4,1,3,12,None),('T324F5','Сапоги',4699,1,6,1,2,5,None),
        ('K358H6','Тапочки',599,1,4,2,20,2,None),('H535R5','Ботинки',2300,2,4,1,2,7,None)]
    x.executemany("INSERT INTO products VALUES(?,?,?,?,?,?,?,?,?)", prods)
    c.commit(); c.close()

class App:
    def __init__(self):
        self.r = tk.Tk(); self.r.title("ООО «Обувь»"); self.r.geometry("950x550"); self.r.configure(bg=BG)
        try: self.r.iconbitmap(ICO)
        except: pass
        self.role = None; self.uid = None; self.cart = []
        self.login(); self.r.mainloop()

    def clr(self):
        for w in self.r.winfo_children(): w.destroy()

    def login(self):
        self.clr()
        tk.Label(self.r, text="ООО «Обувь»", font=("Times New Roman",22,"bold"), bg=BG).pack(pady=20)
        tk.Label(self.r, text="[ЛОГО]", font=F, bg=BG2, width=20, height=4).pack(pady=10)
        f = tk.Frame(self.r, bg=BG); f.pack(pady=10)
        lg = tk.Entry(f, font=F); pw = tk.Entry(f, font=F, show="*")
        tk.Label(f, text="Логин:", bg=BG, font=F).grid(row=0, column=0, sticky="e", pady=3)
        tk.Label(f, text="Пароль:", bg=BG, font=F).grid(row=1, column=0, sticky="e", pady=3)
        lg.grid(row=0, column=1, padx=5); pw.grid(row=1, column=1, padx=5)
        def auth():
            c = db(); u = c.execute("SELECT*FROM users WHERE login=? AND pwd=?", (lg.get(), pw.get())).fetchone(); c.close()
            if u: self.role = u["role"]; self.uid = u["id"]; self.main()
            else: messagebox.showerror("Ошибка","Неверный логин или пароль")
        tk.Button(self.r, text="Войти", bg=AC, font=FB, width=20, command=auth).pack(pady=8)
        tk.Button(self.r, text="Войти как гость", bg=BG2, font=F, width=20,
                  command=lambda: (setattr(self,"role","guest"), self.main())).pack()

    def main(self):
        self.clr()
        top = tk.Frame(self.r, bg=BG2); top.pack(fill="x")
        tk.Label(top, text=f"Роль: {self.role}", bg=BG2, font=FB).pack(side="left", padx=10, pady=6)
        tk.Button(top, text="Товары", bg=AC, font=F, command=self.products).pack(side="left", padx=3)
        if self.role in ("manager","admin"):
            tk.Button(top, text="Заказы", bg=AC, font=F, command=self.orders).pack(side="left", padx=3)
        if self.role == "client":
            tk.Button(top, text="Корзина", bg=AC, font=FB, command=self.show_cart).pack(side="left", padx=3)
        tk.Button(top, text="Выйти", bg=AC, font=F, command=self.login).pack(side="right", padx=10)
        self.body = tk.Frame(self.r, bg=BG); self.body.pack(fill="both", expand=True, padx=10, pady=10)
        self.products()

    def _cb(self):
        for w in self.body.winfo_children(): w.destroy()

    def show_cart(self):
        w = tk.Toplevel(self.r); w.title("Корзина"); w.configure(bg=BG); w.geometry("300x150")
        tk.Label(w, text=f"Товаров в корзине: {len(self.cart)}", bg=BG, font=FB).pack(pady=15)
        def order():
            if not self.cart: return
            c = db()
            for art in self.cart: c.execute("INSERT INTO orders(user_id,article,status) VALUES(?,?,?)", (self.uid, art, "Новый"))
            c.commit(); c.close(); self.cart.clear(); messagebox.showinfo("Успех", "Заказ оформлен!"); w.destroy()
        tk.Button(w, text="Оформить заказ", bg=AC, font=FB, command=order).pack(pady=10)

    def products(self):
        self._cb()
        full = self.role in ("manager","admin")
        srch = tk.StringVar(); sort = tk.StringVar(value="article")
        if full:
            t = tk.Frame(self.body, bg=BG); t.pack(fill="x")
            tk.Label(t, text="Поиск:", bg=BG, font=F).pack(side="left")
            tk.Entry(t, textvariable=srch, font=F).pack(side="left", padx=5)
            tk.Label(t, text="Сортировка:", bg=BG, font=F).pack(side="left")
            ttk.Combobox(t, textvariable=sort, values=["article","name","price","discount"],
                         state="readonly", width=12).pack(side="left", padx=5)
            tk.Button(t, text="Применить", bg=AC, font=F, command=lambda: ref()).pack(side="left", padx=5)

        main_f = tk.Frame(self.body, bg=BG); main_f.pack(fill="both", expand=True, pady=5)
        cols = ("article","name","category","maker","price","discount","stock")
        hdrs = ("Артикул","Название","Категория","Производитель","Цена","Скидка %","Склад")
        tree = ttk.Treeview(main_f, columns=cols, show="headings", height=15)
        for c,h in zip(cols,hdrs): tree.heading(c,text=h); tree.column(c,width=100)
        tree.tag_configure("hi", background=HI, foreground="white")
        tree.pack(side="left", fill="both", expand=True)

        # Вывод фото
        img_lbl = tk.Label(main_f, bg=BG, text="Нет фото", width=20); img_lbl.pack(side="right", padx=10)
        def on_sel(e):
            art = self._sel(tree, quiet=True)
            if not art: return
            c = db(); p = c.execute("SELECT photo FROM products WHERE article=?", (art,)).fetchone(); c.close()
            try:
                if p and p["photo"]:
                    self.img = tk.PhotoImage(file=os.path.join(BASE, p["photo"]))
                    img_lbl.config(image=self.img, text="")
                else: img_lbl.config(image="", text="Нет фото")
            except: img_lbl.config(image="", text="Фото не найдено")
        tree.bind("<<TreeviewSelect>>", on_sel)

        def ref():
            tree.delete(*tree.get_children())
            q = "SELECT p.*, c.name cat, m.name mk FROM products p LEFT JOIN categories c ON c.id=p.category_id LEFT JOIN makers m ON m.id=p.maker_id"
            args = []
            if full:
                if srch.get(): q += " WHERE p.name LIKE ?"; args.append(f"%{srch.get()}%")
                q += f" ORDER BY p.{sort.get()}"
            c = db()
            for p in c.execute(q, args).fetchall():
                tag = "hi" if (p["discount"] or 0) > 15 else ""
                tree.insert("", "end", values=(p["article"],p["name"],p["cat"],p["mk"],p["price"],p["discount"],p["stock"]), tags=(tag,))
            c.close()
        ref()

        if self.role == "admin":
            b = tk.Frame(self.body, bg=BG); b.pack(pady=5)
            tk.Button(b, text="Добавить", bg=AC, font=F, command=lambda: self.edit_p(None, ref)).pack(side="left", padx=3)
            tk.Button(b, text="Изменить", bg=AC, font=F, command=lambda: self.edit_p(self._sel(tree), ref)).pack(side="left", padx=3)
            tk.Button(b, text="Удалить", bg=AC, font=F, command=lambda: self._del(tree,"products","article",ref)).pack(side="left", padx=3)
        elif self.role == "client":
            tk.Button(self.body, text="В корзину", bg=AC, font=FB,
                      command=lambda: (self.cart.append(self._sel(tree)), messagebox.showinfo("","В корзине!")) if self._sel(tree) else None).pack(pady=5)

    def edit_p(self, art, cb):
        w = tk.Toplevel(self.r); w.title("Товар"); w.configure(bg=BG)
        c = db()
        cats = c.execute("SELECT*FROM categories").fetchall(); mks = c.execute("SELECT*FROM makers").fetchall()
        sups = c.execute("SELECT*FROM suppliers").fetchall()
        r = c.execute("SELECT*FROM products WHERE article=?",(art,)).fetchone() if art else None
        c.close()
        v = {k: tk.StringVar() for k in ("article","name","price","discount","stock","cat","mk","sup")}
        if r:
            for k in ("article","name","price","discount","stock"): v[k].set(r[k])
            for o in cats:
                if o["id"]==r["category_id"]: v["cat"].set(f"{o['id']}:{o['name']}")
            for o in mks:
                if o["id"]==r["maker_id"]: v["mk"].set(f"{o['id']}:{o['name']}")
            for o in sups:
                if o["id"]==r["supplier_id"]: v["sup"].set(f"{o['id']}:{o['name']}")

        rows = [("Артикул", tk.Entry(w, textvariable=v["article"], font=F)),
                ("Название", tk.Entry(w, textvariable=v["name"], font=F)),
                ("Цена", tk.Entry(w, textvariable=v["price"], font=F)),
                ("Скидка %", tk.Entry(w, textvariable=v["discount"], font=F)),
                ("Склад", tk.Entry(w, textvariable=v["stock"], font=F)),
                ("Категория", ttk.Combobox(w, textvariable=v["cat"], state="readonly", values=[f"{o['id']}:{o['name']}" for o in cats])),
                ("Производитель", ttk.Combobox(w, textvariable=v["mk"], state="readonly", values=[f"{o['id']}:{o['name']}" for o in mks])),
                ("Поставщик", ttk.Combobox(w, textvariable=v["sup"], state="readonly", values=[f"{o['id']}:{o['name']}" for o in sups]))]
        for i,(lbl,wd) in enumerate(rows):
            tk.Label(w, text=lbl, bg=BG, font=F).grid(row=i,column=0,padx=5,pady=2,sticky="e")
            wd.grid(row=i, column=1, padx=5, pady=2, sticky="we")
        if r: rows[0][1].config(state="readonly")

        def save():
            try:
                fid = lambda s: int(s.split(":")[0]) if s else None
                c = db(); vals = (v["name"].get(), float(v["price"].get()), fid(v["sup"].get()), fid(v["mk"].get()), fid(v["cat"].get()), int(v["discount"].get() or 0), int(v["stock"].get() or 0))
                if r: c.execute("UPDATE products SET name=?,price=?,supplier_id=?,maker_id=?,category_id=?,discount=?,stock=? WHERE article=?", vals+(art,))
                else: c.execute("INSERT INTO products(article,name,price,supplier_id,maker_id,category_id,discount,stock) VALUES(?,?,?,?,?,?,?,?)", (v["article"].get(),)+vals)
                c.commit(); c.close(); w.destroy(); cb()
            except Exception as e: messagebox.showerror("Ошибка", str(e))
        tk.Button(w, text="Сохранить", bg=AC, font=FB, command=save).grid(row=len(rows), columnspan=2, pady=10)

    def orders(self):
        self._cb(); cols = ("id","client","article","status")
        tree = ttk.Treeview(self.body, columns=cols, show="headings", height=17)
        for c,n in zip(cols, ("ID","Клиент","Артикул","Статус")): tree.heading(c, text=n); tree.column(c, width=180)
        tree.pack(fill="both", expand=True, pady=5)
        def ref():
            tree.delete(*tree.get_children()); c = db()
            for r in c.execute("SELECT o.id, u.login, o.article, o.status FROM orders o LEFT JOIN users u ON u.id=o.user_id").fetchall(): tree.insert("", "end", values=tuple(r))
            c.close()
        ref()
        if self.role == "admin":
            b = tk.Frame(self.body, bg=BG); b.pack(pady=5)
            tk.Button(b, text="Добавить", bg=AC, font=F, command=lambda: self.edit_o(None, ref)).pack(side="left", padx=3)
            tk.Button(b, text="Изменить", bg=AC, font=F, command=lambda: self.edit_o(self._sel(tree), ref)).pack(side="left", padx=3)
            tk.Button(b, text="Удалить", bg=AC, font=F, command=lambda: self._del(tree,"orders","id",ref)).pack(side="left", padx=3)

    def edit_o(self, oid, cb):
        w = tk.Toplevel(self.r); w.title("Заказ"); w.configure(bg=BG)
        c = db(); us = c.execute("SELECT id,login FROM users WHERE role='client'").fetchall(); ps = c.execute("SELECT article,name FROM products").fetchall()
        r = c.execute("SELECT*FROM orders WHERE id=?",(oid,)).fetchone() if oid else None
        c.close()
        uv, pv, sv = tk.StringVar(), tk.StringVar(), tk.StringVar(value="Новый")
        if r:
            sv.set(r["status"])
            for u in us:
                if u["id"]==r["user_id"]: uv.set(f"{u['id']}:{u['login']}")
            for p in ps:
                if p["article"]==r["article"]: pv.set(f"{p['article']}:{p['name']}")
        tk.Label(w, text="Клиент", bg=BG, font=F).grid(row=0, column=0, padx=5, pady=3, sticky="e")
        ttk.Combobox(w, textvariable=uv, state="readonly", width=35, values=[f"{u['id']}:{u['login']}" for u in us]).grid(row=0, column=1, padx=5)
        tk.Label(w, text="Товар", bg=BG, font=F).grid(row=1, column=0, padx=5, pady=3, sticky="e")
        ttk.Combobox(w, textvariable=pv, state="readonly", width=35, values=[f"{p['article']}:{p['name']}" for p in ps]).grid(row=1, column=1, padx=5)
        tk.Label(w, text="Статус", bg=BG, font=F).grid(row=2, column=0, padx=5, pady=3, sticky="e")
        ttk.Combobox(w, textvariable=sv, state="readonly", width=35, values=["Новый","Отправлен","Доставлен","Завершен"]).grid(row=2, column=1, padx=5)
        def save():
            try:
                c = db()
                if oid: c.execute("UPDATE orders SET status=? WHERE id=?", (sv.get(), oid))
                else: c.execute("INSERT INTO orders(user_id,article,status) VALUES(?,?,?)", (int(uv.get().split(":")[0]), pv.get().split(":")[0], sv.get()))
                c.commit(); c.close(); w.destroy(); cb()
            except Exception as e: messagebox.showerror("Ошибка", str(e))
        tk.Button(w, text="Сохранить", bg=AC, font=FB, command=save).grid(row=3, columnspan=2, pady=10)

    def _sel(self, tree, quiet=False):
        s = tree.selection()
        if not s:
            if not quiet: messagebox.showwarning("!", "Выберите запись")
            return None
        return tree.item(s[0], "values")[0]

    def _del(self, tree, table, pk, cb):
        i = self._sel(tree)
        if not i: return
        if messagebox.askyesno("Удалить?", "Подтвердите удаление"):
            c = db(); c.execute(f"DELETE FROM {table} WHERE {pk}=?", (i,)); c.commit(); c.close(); cb()

if __name__ == "__main__":
    if not os.path.exists(DB): init()
    App()