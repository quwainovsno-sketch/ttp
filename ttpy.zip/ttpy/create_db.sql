-- Создание БД для SQL Server Management Studio
-- Запускать в SSMS: File → New → Query, вставить, F5

IF DB_ID('shop') IS NOT NULL
BEGIN
    ALTER DATABASE shop SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE shop;
END
GO

CREATE DATABASE shop;
GO
USE shop;
GO

CREATE TABLE users(
    id INT IDENTITY(1,1) PRIMARY KEY,
    login NVARCHAR(50) UNIQUE NOT NULL,
    pwd NVARCHAR(50) NOT NULL,
    role NVARCHAR(20) NOT NULL
);

CREATE TABLE suppliers(
    id INT PRIMARY KEY,
    name NVARCHAR(100) UNIQUE NOT NULL
);

CREATE TABLE makers(
    id INT PRIMARY KEY,
    name NVARCHAR(100) UNIQUE NOT NULL
);

CREATE TABLE categories(
    id INT PRIMARY KEY,
    name NVARCHAR(100) UNIQUE NOT NULL
);

CREATE TABLE products(
    article NVARCHAR(20) PRIMARY KEY,
    name NVARCHAR(100) NOT NULL,
    price FLOAT NOT NULL,
    supplier_id INT FOREIGN KEY REFERENCES suppliers(id),
    maker_id INT FOREIGN KEY REFERENCES makers(id),
    category_id INT FOREIGN KEY REFERENCES categories(id),
    discount INT DEFAULT 0,
    stock INT DEFAULT 0
);

CREATE TABLE orders(
    id INT IDENTITY(1,1) PRIMARY KEY,
    user_id INT FOREIGN KEY REFERENCES users(id),
    article NVARCHAR(20) FOREIGN KEY REFERENCES products(article),
    status NVARCHAR(20) DEFAULT N'Новый'
);
GO

-- Пользователи
INSERT INTO users(login, pwd, role) VALUES
('admin','1','admin'),('manager','1','manager'),('client','1','client');

-- Поставщики
INSERT INTO suppliers(id, name) VALUES
(1, N'Kari'), (2, N'Обувь для вас');

-- Производители
INSERT INTO makers(id, name) VALUES
(1, N'Kari'), (2, N'Marco Tozzi'), (3, N'Рос'),
(4, N'Rieker'), (5, N'Alessio Nesca'), (6, N'CROSBY');

-- Категории
INSERT INTO categories(id, name) VALUES
(1, N'Женская обувь'), (2, N'Мужская обувь');

-- Товары
INSERT INTO products(article, name, price, supplier_id, maker_id, category_id, discount, stock) VALUES
(N'А112Т4', N'Ботинки', 4990, 1, 1, 1, 3, 6),
(N'F635R4', N'Ботинки', 3244, 2, 2, 1, 2, 13),
(N'H782T5', N'Туфли', 4499, 1, 1, 2, 4, 5),
(N'G783F5', N'Ботинки', 5900, 1, 3, 2, 2, 8),
(N'J384T6', N'Ботинки', 3800, 2, 4, 2, 2, 16),
(N'D572U8', N'Кроссовки', 4100, 2, 3, 2, 3, 6),
(N'F572H7', N'Туфли', 2700, 1, 2, 1, 2, 14),
(N'D329H3', N'Полуботинки', 1890, 2, 5, 1, 4, 4),
(N'B320R5', N'Туфли', 4300, 1, 4, 1, 2, 6),
(N'G432E4', N'Туфли', 2800, 1, 1, 1, 3, 15),
(N'S213E3', N'Полуботинки', 2156, 2, 6, 2, 3, 6),
(N'E482R4', N'Полуботинки', 1800, 1, 1, 1, 2, 14),
(N'S634B5', N'Кеды', 5500, 2, 6, 2, 3, 0),
(N'K345R4', N'Полуботинки', 2100, 2, 6, 2, 2, 3),
(N'O754F4', N'Туфли', 5400, 2, 4, 1, 4, 18),
(N'G531F4', N'Ботинки', 6600, 1, 1, 1, 12, 9),
(N'J542F5', N'Тапочки', 500, 1, 1, 2, 13, 0),
(N'B431R5', N'Ботинки', 2700, 2, 4, 2, 2, 5),
(N'P764G4', N'Туфли', 6800, 1, 6, 1, 15, 15),
(N'C436G5', N'Ботинки', 10200, 1, 5, 1, 15, 9),
(N'F427R5', N'Ботинки', 11800, 2, 4, 1, 15, 11),
(N'N457T5', N'Полуботинки', 4600, 1, 6, 1, 3, 13),
(N'D364R4', N'Туфли', 12400, 1, 1, 1, 16, 5),
(N'S326R5', N'Тапочки', 9900, 2, 6, 2, 17, 15),
(N'L754R4', N'Полуботинки', 1700, 1, 1, 1, 2, 7),
(N'M542T5', N'Кроссовки', 2800, 2, 4, 2, 18, 3),
(N'D268G5', N'Туфли', 4399, 2, 4, 1, 3, 12),
(N'T324F5', N'Сапоги', 4699, 1, 6, 1, 2, 5),
(N'K358H6', N'Тапочки', 599, 1, 4, 2, 20, 2),
(N'H535R5', N'Ботинки', 2300, 2, 4, 1, 2, 7);
GO
